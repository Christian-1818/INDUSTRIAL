class Triangle
{
public:
	Triangle(double a, double b,double c);
	double getPerimeter();
	double getArea();

private:
	double sideA, sideB, sideC;
};