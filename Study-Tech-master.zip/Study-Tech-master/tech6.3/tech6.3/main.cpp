#include <iostream>
#include <ctime>
//#include "Ocean.h"
//#include "Sea.h"
#include "bay.h"

using namespace std;

int main()
{
	setlocale(LC_ALL, "Russian");

	srand(time(NULL));

	//Ocean Ocean1(NamesOcean[rand() % 8], rand() % 8500 + 3500, (rand() % 1000000 + 200000) / 10.0);
	//Sea Sea1(NamesSea[rand() % 8], rand() % 8500 + 3500, (rand() % 100000 + 20000) / 10.0);
	//Zaliv Zaliv1(NamesZaliv[rand() % 8], rand() % 8500 + 3500, (rand() % 10000 + 2000) / 10.0);

	return 0;
}